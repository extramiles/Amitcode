Following Test Cases are present in "PVT_ALM" folder under "PVT_ALM__3_" Folder:

OPUS LD	Reg_TC01 IPTV change order, Script Name-"MI_IPTV_Change"

OPUS LD	Reg_TC02 HSIA Upgrade, Script Name-"MI_Internet_Change_Up"

OPUS LD	Reg_TC03 HSIA Downgrade, Script Name-"MI_Internet_Change_Downgrade"

OPUS LD	Reg_TC04 VoIP Change, Script Name-"MI_VOIP_Change"

OPUS LD	Reg_TC06 New Provide, DTV Only Script Name-"PVT_LD_DTV_only"

OPUS LD	Reg_TC07 DTV Provide amend, Script Name-"MI_DTV_Amend_Equip"

OPUS LD	Reg_TC08 DTV Change Order - programming change, Script Name-"MI_DTV_Change"

OPUS LD	Reg_TC09 DTV Change order - Add equip, Script Name-"MI_DTV_Change_Equip"



Following Test Cases are present in "PVT_ALM2" folder under "PVT_ALM__3_" Folder:

OPUS LD	Reg_TC05 New Wireless + New HSIA + New DTV, Script Name-"PVT_LD_wrls_HSIA_DTV"

OPUS LD	Reg_TC10 Existing WLS customer - add a line, Script Name-"PVT_LD_Wrls_AAL"

OPUS LD	Reg_TC11 Existing WLS customer - rate plan change, Script Name-"PVT_LD_Wrls_RatePlanChange"






