var async = require('async');
var MongoClient = require('mongodb').MongoClient;


var Opus_URL = 'mongodb://10.13.65.115:27017/automationframework';
var OpusMobile_URL = 'mongodb://10.13.65.5:27017/automationframework';
var Other_URL = 'mongodb://10.13.66.140:27017/automationframework';



var database = {
  OPUS_automation: async.apply(MongoClient.connect, Opus_URL,{
    reconnectTries: Number.MAX_VALUE,
    reconnectInterval: 1000
  }),
  OM_automation: async.apply(MongoClient.connect, OpusMobile_URL, {
    reconnectTries: Number.MAX_VALUE,
    reconnectInterval: 1000
  })
};

console.log('Connected to DB');
module.exports = function (cb) {
  async.parallel(database, cb)
};
