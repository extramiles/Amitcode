import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateTestSheetComponent } from './create-test-sheet.component';

describe('CreateTestSheetComponent', () => {
  let component: CreateTestSheetComponent;
  let fixture: ComponentFixture<CreateTestSheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateTestSheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateTestSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
