import { Component, OnInit, OnDestroy } from '@angular/core';
import { StateDataService } from '../../shared/state-data-service';
import { ActivatedRoute, Router } from '@angular/router';
import { ExportToExcelService } from '../../shared/export-to-excel.service';

@Component({
  selector: 'app-create-test-sheet',
  templateUrl: './create-test-sheet.component.html',
  styleUrls: ['./create-test-sheet.component.css']
})
export class CreateTestSheetComponent implements OnInit, OnDestroy {
  sheetName = '';
  pid = '';
  projectName = '';
  release = '';
  tagValue = '';
  store = '';
  title = '';
  testCaseNumber: number = 1;
  description = ''
  reference = '';

  titleEditTestcase = '';
  descriptionEditTestcase = '';
  referenceEditTestcase = '';
  indexEdit: number;
  fileselectMethod= "Test Sheet Created";
  testcases: { Title: string, Description: string, Reference: string }[] = [];


  constructor(private stateDataService: StateDataService,
    private route: ActivatedRoute,
    private router: Router,
    private etoexcelService: ExportToExcelService
  ) { }

  ngOnInit() {
   let createdSheetInfo =  this.stateDataService.getCreatedSheetInfo();
   let testSheetCreated = this.stateDataService.getTestSheetCreated();
    this.pid = createdSheetInfo.pid;
    this.projectName = createdSheetInfo.projectName;
    this.release = createdSheetInfo.release;
    this.store = createdSheetInfo.currentStore;
    this.tagValue = createdSheetInfo.tagValue;
    this.testCaseNumber = createdSheetInfo.testCaseNumber;

    this.testcases = testSheetCreated.testcases;

    this.setSheetName();
    this.reference = this.stateDataService.getReference();
    this.description = this.stateDataService.getDescription();
  }

  setSheetName() {
    this.sheetName = this.pid + ' ' + this.projectName;
    this.setTestCaseTitle();
  }
  setTestCaseTitle() {
    this.title = this.release + '_' + this.pid + ' ' + this.projectName + ' ' + this.store + '_TC0' + this.testCaseNumber;
  }
  correctTagValue() {
    this.tagValue = this.tagValue.replace(/ /g, '_');
  }

  onSaveTestCase() {
    this.testcases.push({ Title: this.title, Description: this.description, Reference: this.reference });
    this.testCaseNumber = this.testCaseNumber + 1;
    this.setTestCaseTitle();
  }
  editTestCase(index) {
    this.indexEdit = index;
    this.titleEditTestcase = this.testcases[index].Title;
    this.descriptionEditTestcase = this.testcases[index].Description;
    this.referenceEditTestcase = this.testcases[index].Reference;
  }

  onSaveEditedTestCase() {
    this.testcases[this.indexEdit].Title = this.titleEditTestcase;
    this.testcases[this.indexEdit].Description = this.descriptionEditTestcase;
    this.testcases[this.indexEdit].Reference = this.referenceEditTestcase;
  }
  deleteTestCase(index) {
    this.testcases.splice(index, 1);
  }

  onUpload() {
    this.stateDataService.pushData({ fileName: this.sheetName, fileselectMethod: this.fileselectMethod, testcases: this.testcases });
    this.sheetName = '';
    this.fileselectMethod = '';
    this.testcases = [];
    this.pid = '';
    this.projectName = '';
    this.release = '';
    this.tagValue = '';
    this.store = '';
    this.testCaseNumber = 1;
    this.router.navigate(['../finalSubmit'], { relativeTo: this.route });
  }

  onExport() {
    this.etoexcelService.exportAsExcelFile(
      this.testcases,
      this.sheetName);
  }

  ngOnDestroy() {
    this.stateDataService.setTestSheetCreated({ fileName: this.sheetName, fileselectMethod: this.fileselectMethod, testcases: this.testcases },
      { pid: this.pid, projectName: this.projectName, release: this.release, tagValue: this.tagValue, currentStore: this.store, testCaseNumber: this.testCaseNumber });
    this.stateDataService.setdescReference(this.description, this.reference);
  }
}
