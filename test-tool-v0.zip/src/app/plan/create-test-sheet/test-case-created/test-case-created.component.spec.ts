import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestCaseCreatedComponent } from './test-case-created.component';

describe('TestCaseCreatedComponent', () => {
  let component: TestCaseCreatedComponent;
  let fixture: ComponentFixture<TestCaseCreatedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestCaseCreatedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestCaseCreatedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
