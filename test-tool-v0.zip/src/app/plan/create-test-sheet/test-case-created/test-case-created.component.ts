import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-test-case-created',
  templateUrl: './test-case-created.component.html',
  styleUrls: ['./test-case-created.component.css']
})
export class TestCaseCreatedComponent implements OnInit {
  @Input() testcase: { Title: string, Description: string, Reference: string };
  @Input() index: number;
  constructor() { }

  ngOnInit() {
  }

}
