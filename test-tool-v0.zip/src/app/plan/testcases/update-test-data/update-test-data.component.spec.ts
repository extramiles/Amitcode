import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateTestDataComponent } from './update-test-data.component';

describe('UpdateTestDataComponent', () => {
  let component: UpdateTestDataComponent;
  let fixture: ComponentFixture<UpdateTestDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateTestDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateTestDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
