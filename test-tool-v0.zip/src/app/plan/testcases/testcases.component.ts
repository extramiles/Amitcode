import { Component, OnInit, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { DataService } from '../../shared/data.service';
import { TestcaseStateService } from '../../shared/testcase-state.service';
import { ExportToExcelService } from '../../shared/export-to-excel.service';


@Component({
  selector: 'app-testcases',
  templateUrl: './testcases.component.html',
  styleUrls: ['./testcases.component.css']
})
export class TestcasesComponent implements OnInit,OnDestroy{


  testPhase = ['Unassigned', 'Assembly Test', 'CLEC Test', 'End to End Test (E2E)', 'Integrated Systems Test (IST)', 'Integrated Systems Testing',
    'Iteration Test', 'Performance/Load', 'Production', 'Production Validation Test (PVT)', 'Rapid Deployment Test (RD)',
    'Sanity / Shakeout', 'Security', 'Undefined', 'Unit Test', 'User Acceptance Test (UAT)'];
  application = ['OPUS - C:18257'];

  nonMOTSTeam = ['RCC ST-OPUS', 'RCC ST-OPUSMBL', 'RCC-ST-OPUS-CC','RCC-ST-OPUSMBL-CC'];


  testCaseViewMethod = '';
  testCaseTags;
  testSetName;
  tagValue='';
  setValue = '';
  testcases;
  testcasesWithSteps;
  searchTestcaseByKey = '';
  sheetName = 'BlankSheet';
  optionsToDisplay = 'update';
  loadTestSteps = false;

  sortcol = 'name';
  reverseSort = false;

  title = '';
  description = '';
  _idtestcaseToBeUpdated: string;
  testcaseToBeUpdated;
  errorMessageTestCaseUpdateFail: string;
  filteredTestCaseData:any[]=[];
  url = '';


  testPhaseSelected = 'Integrated Systems Test (IST)';
  regreProgression = 'Progression';
  applicationSelected = 'OPUS - C:18257';
  nonMOTSTeamSelected = 'RCC ST-OPUS';
  suitNameModified = '';
  suitDescriptionModified = '';
  user1Modified = 'User 1';
  user2Modified = 'User 2';

  constructor(private dataService: DataService,
    private testcaseStateService: TestcaseStateService,
    private etoexcelService: ExportToExcelService
  ) { }

  sortData(name) {
    this.reverseSort = (this.sortcol === name) ? !this.reverseSort : false;
    this.sortcol = name;
  }

  filterFunction(items: any[], searchText) {
    if (!items) return [];
    if (!searchText) return items;
    let filteredTestCaseData1 = [];
    searchText = searchText.toLowerCase();
    for (let it of items) {
      if (it.Description.toLowerCase().includes(searchText) || it.Title.toLowerCase().includes(searchText)) {
        filteredTestCaseData1.push(it);
        }
    }
    return filteredTestCaseData1;
  }



  setUrl() {
    this.testCaseViewMethod = '';
    this.testCaseTags = '';
    this.testSetName = '';
    this.dataService.setUrl(this.url);
  }

  getTagNameOrSetName() {
    if (this.testCaseViewMethod === 'tag') {
      this.dataService.getTestcaseTag(this.url).subscribe((result) => {
        this.testCaseTags= result;
      });    
    } else if (this.testCaseViewMethod === 'testSetName') {
      this.dataService.getTestSetName(this.url).subscribe((result) => {
        this.testSetName = result;
      });  
    }
  }
  loadTestCases() {
    if (!this.loadTestSteps && this.optionsToDisplay !== 'update' && this.optionsToDisplay !== 'testData') {
      this.optionsToDisplay = 'tdpWithoutStep';
    }
    this.testcaseStateService.setTestCasesWithSteps([]);
    if (this.url === 'OPUS_automation') {
      this.sheetName = 'OPUS';
    } else if (this.url === 'OM_automation') {
      this.sheetName = 'OPUSMobile';
    } else {
      this.sheetName = this.url;
    }

    this.testcaseStateService.resetValues();
    this.resetValues();
    //getTestCase call

    if (this.testCaseViewMethod === 'tag' && this.tagValue !== '') {
      this.testcases = [];
      this.testcasesWithSteps = [];
      this.testcaseStateService.setTestCases(this.testcases, this.sheetName);
      this.testcaseStateService.setTestCasesWithSteps(this.testcasesWithSteps);
      for (let tValue of this.tagValue) {
        this.getTestCasesByTag(tValue);
      }
    } else if (this.testCaseViewMethod === 'testSetName' && this.setValue !== '') {
     this.testcases = [];
      this.testcasesWithSteps = [];
      this.testcaseStateService.setTestCases(this.testcases, this.sheetName);
      this.testcaseStateService.setTestCasesWithSteps(this.testcasesWithSteps);
      for (let sValue of this.setValue) {
        this.getTestCasesBySet(sValue);
      }
    }

  }


  getTestCasesByTag(tagValue) {
    this.sheetName = this.sheetName +' '+ tagValue;
    this.testcaseStateService.setSuitName(this.sheetName);
    this.testcaseStateService.setSuitDescription(this.sheetName);
    this.suitNameModified = this.sheetName;
    this.suitDescriptionModified = this.sheetName;

    this.dataService.getTestCasesByTag(this.url, tagValue).subscribe((result) => {   
        this.testcases.push(result);
      this.testcaseStateService.setTestCases(this.testcases, this.sheetName);
    });
    if (this.loadTestSteps) {
      this.dataService.getTestCasesByTagWithSteps(this.url, tagValue).subscribe((result) => {
        this.testcasesWithSteps.push(result);
        this.testcaseStateService.setTestCasesWithSteps(this.testcasesWithSteps);
        this.optionsToDisplay = 'tdpWithStep';
      });
    } 
  }

  getTestCasesBySet(setValue) {
    this.sheetName = this.sheetName +' ' +setValue;
    this.testcaseStateService.setSuitDescription(this.sheetName);
    this.testcaseStateService.setSuitName(this.sheetName);
    this.suitNameModified = this.sheetName;
    this.suitDescriptionModified = this.sheetName;
    this.dataService.getTestCasesBySetName(this.url, setValue).subscribe((result) => {
      this.testcases.push(result);
      this.testcaseStateService.setTestCases(this.testcases, this.sheetName);
    });
    if (this.loadTestSteps) {

      this.dataService.getTestCasesBySetWithSteps(this.url, setValue).subscribe((result) => {
        this.testcasesWithSteps.push(result);
        this.testcaseStateService.setTestCasesWithSteps(this.testcasesWithSteps);
        this.optionsToDisplay = 'tdpWithStep';
      });
    }
  }

 

  exportTestCases() {
    if (this.optionsToDisplay === 'update') {

      this.filteredTestCaseData = this.filterFunction(this.testcaseStateService.getTestCaseList(), this.searchTestcaseByKey);

      this.etoexcelService.exportAsExcelFile(
        this.filteredTestCaseData,
        this.sheetName);
    }
    else if (this.optionsToDisplay === 'tdpWithoutStep') {
      this.etoexcelService.exportTableWithoutSteps(this.sheetName);
    }
    else if (this.optionsToDisplay === 'tdpWithStep') {
      this.etoexcelService.exportTableWithSteps(this.sheetName);
    }
  }

  testCaseViewFormate(value:string) {
    this.optionsToDisplay = value;
  }

  setCurrentTestCaseValue(testcase) {
    this.title = testcase.name;
    this.description = testcase.description;
    this._idtestcaseToBeUpdated = testcase._id;
    this.testcaseToBeUpdated = testcase;
    this.errorMessageTestCaseUpdateFail = '';
  }


  onSubmitTestCase1() {
    this.dataService.updateTestCaseById(this.url, this._idtestcaseToBeUpdated, this.title, this.description).subscribe((result) => {
      this.loadTestCases();
    });
  }

  onSubmitTestCase() {
    if (this.title.trim() === this.testcaseToBeUpdated.name) {
      this.dataService.updateTestCaseById(this.url, this._idtestcaseToBeUpdated, this.title, this.description).subscribe((result) => {
        this.loadTestCases();
      });
    } else {
      this.dataService.searchExistingTestcaseByName(this.url, this.title.trim()).subscribe((result: { name: string, success: boolean, errorMessage: string }) => {
        if (result.success) {
          this.dataService.updateTestCaseById(this.url, this._idtestcaseToBeUpdated, this.title.trim(), this.description).subscribe((result) => {
            this.loadTestCases();
            this.errorMessageTestCaseUpdateFail = '';
          });
        } else {
          this.errorMessageTestCaseUpdateFail = result.name + ' ' + result.errorMessage;
        }
      });
    }
    
  }


  testExportModelChanged() {
    this.testcaseStateService.setSuitDescription(this.suitDescriptionModified);
    this.testcaseStateService.setSuitName(this.suitNameModified);
    this.testcaseStateService.setTestPhaseSelected(this.testPhaseSelected);
    this.testcaseStateService.setRegreProgression(this.regreProgression);
    this.testcaseStateService.setapplicationSelected(this.applicationSelected);
    this.testcaseStateService.setnonMOTSTeamSelected(this.nonMOTSTeamSelected);
    this.testcaseStateService.setuser1Modified(this.user1Modified);
    this.testcaseStateService.setuser2Modified(this.user2Modified);
  }


  resetValues() {
    this.testPhaseSelected = 'Integrated Systems Test (IST)';
    this.regreProgression = 'Progression';
    this.applicationSelected = 'OPUS - C:18257';
    this.nonMOTSTeamSelected = 'RCC ST-OPUS';
    this.user1Modified = 'User 1';
    this.user2Modified = 'User 2';
  }


  ngOnInit() {

    this.suitNameModified = this.testcaseStateService.getSuitName();
    this.suitDescriptionModified = this.testcaseStateService.getSuitDescription();
    this.user1Modified = this.testcaseStateService.getUser1Modified();
    this.user2Modified = this.testcaseStateService.getUser2Modified();
    this.regreProgression = this.testcaseStateService.getRegreProgression();
    this.applicationSelected = this.testcaseStateService.getApplicationSelected();
    this.nonMOTSTeamSelected = this.testcaseStateService.getNonMOTSTeamSelected();
    this.testPhaseSelected = this.testcaseStateService.getTestPhaseSelected();
    this.optionsToDisplay = this.testcaseStateService.getOptionsToDisplay();
    this.testcases = this.testcaseStateService.getTestCases();
    this.sheetName = this.testcaseStateService.getSheetName();
    this.suitNameModified = this.sheetName;
    this.suitDescriptionModified = this.sheetName;
  }

  ngOnDestroy() {
    this.testcaseStateService.setTestCases(this.testcases, this.sheetName);
    this.testcaseStateService.setOptionsToDisplay(this.optionsToDisplay);
  }

}
