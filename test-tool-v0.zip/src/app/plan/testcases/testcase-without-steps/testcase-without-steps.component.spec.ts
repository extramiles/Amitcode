import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestcaseWithoutStepsComponent } from './testcase-without-steps.component';

describe('TestcaseWithoutStepsComponent', () => {
  let component: TestcaseWithoutStepsComponent;
  let fixture: ComponentFixture<TestcaseWithoutStepsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestcaseWithoutStepsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestcaseWithoutStepsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
