import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestcaseWithStepsComponent } from './testcase-with-steps.component';

describe('TestcaseWithStepsComponent', () => {
  let component: TestcaseWithStepsComponent;
  let fixture: ComponentFixture<TestcaseWithStepsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestcaseWithStepsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestcaseWithStepsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
