import { Component, OnInit, OnDestroy } from '@angular/core';
import { StateDataService } from '../../shared/state-data-service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-testsheet',
  templateUrl: './testsheet.component.html',
  styleUrls: ['./testsheet.component.css']
})
export class TestsheetComponent implements OnInit, OnDestroy {
  subscription: Subscription;
  dataToUpload = [];

  constructor(private stateDataService: StateDataService) { }

  ngOnInit() {
    this.subscription = this.stateDataService.dataChanged.subscribe(
      (dataToUpload: any[]) => {
        this.dataToUpload = dataToUpload;
      }
    );
    this.dataToUpload = this.stateDataService.getData();
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
