import { Component, OnInit, Input, OnDestroy, OnChanges } from '@angular/core';
import { StateDataService } from '../../../shared/state-data-service';
import { DataService } from '../../../shared/data.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-workbook',
  templateUrl: './workbook.component.html',
  styleUrls: ['./workbook.component.css']
})
export class WorkbookComponent implements OnInit, OnDestroy, OnChanges {
  @Input() testsheet: { fileName: string, fileselectMethod: string, testcases: any[] };
  @Input() index: number;
  tagValue = '';
  tagSetFlag = false;
  testCaseToBeEdited;
  testCaseIndex: number;
  title = '';
  description = '';
  reference = '';
  masterPassword = '';
  subscription: Subscription;
  submitflag = true;
  finishFlag = true;
  submitButton = true;
  inputTagDisabled = false;
  uploadToTaffyButton = 'Upload To Taffy';

  reSubmitIndex: number;
  reSubmitTestCaseDetails;
  correctTitle='test';
  correctDescription='test';
  correctReference = 'test';
  correctValueFlag = false;
  resubmitFlag = false;

  testcaseInsertionReport = [];

  
  url = '';

  constructor(private stateDataService: StateDataService,
              private dataService: DataService
      ) { }

  ngOnInit() {
   
  }
  ngOnChanges() {
   
  }

  correctTagValue() {
    this.tagValue = this.tagValue.replace(/ /g, '_');
    if (this.tagValue === '' || this.url === '' || this.tagValue === 'Enter_Tag' ) {
      this.tagSetFlag = false;
    } else {
      this.tagSetFlag = true;
    }
  }


  onDelete() {
    this.stateDataService.deleteDataByIndex(this.index);
  }
  deleteTestCase(index) {
    this.stateDataService.deleteTestCaseByIndex(this.index,index);
  }

  editTestCase(index) {
    this.title = '';
    this.description = '';
    this.reference = '';

    this.testCaseIndex = index;
    this.testCaseToBeEdited = this.stateDataService.fetchTestCaseByIndex(this.index, index);
    this.title = this.testCaseToBeEdited.Title;
    this.description = this.testCaseToBeEdited.Description;
    this.reference = this.testCaseToBeEdited.Reference;
  }
  onSaveTestCase() {
    this.stateDataService.uploadTestCaseByIndex(this.index, this.testCaseIndex, this.title, this.description, this.reference);
  }

  validateMasterPass() {
    if (this.masterPassword === 'Rahul@466109') {
      this.submitflag = false;
    } else {
      this.submitflag = true;
    }
  }
 
  onUploadTestCase() {

    this.submitButton = false;
    this.inputTagDisabled = true;
    this.uploadToTaffyButton = 'View Report';

    let testcases: {title:string,description:string,reference:string}[]=[];

    for (let testcase of this.testsheet.testcases) {
      let uniqueTestCaseFlag = true;
   let testdata = {
     title: testcase.Title,
     description: testcase.Description,
     reference: testcase.Reference.trim()
      };


      for (let t of testcases) {
        if (t.title === testdata.title) {
          uniqueTestCaseFlag = false;
        }
      }
      if (uniqueTestCaseFlag === true) {
        testcases.push(testdata);
        this.dataService.uploadtestCase(this.url, testdata, this.tagValue).subscribe((result) => {
          this.testcaseInsertionReport.push(result);
          if (this.testsheet.testcases.length === this.testcaseInsertionReport.length) {
            this.finishFlag = false;
          }
        });
      } else {
        this.testcaseInsertionReport.push({ testcase: testdata, success: false, errorMessage: 'Duplicate test case' });
        if (this.testsheet.testcases.length === this.testcaseInsertionReport.length) {
          this.finishFlag = false;
        }
      }
       
    }
  }

  reSubmit(reSubmitIndex, result) {
    this.correctValueFlag = true;
    this.reSubmitTestCaseDetails = result;
    this.reSubmitIndex = reSubmitIndex;
    this.resubmitFlag = true;
    this.correctTitle = this.reSubmitTestCaseDetails.testcase.title;
    this.correctDescription = this.reSubmitTestCaseDetails.testcase.description;
    this.correctReference = this.reSubmitTestCaseDetails.testcase.reference;
      this.correctValueFlag = false; 
  }

  submitWithCorrectValue(correctTitle, correctDescription, correctReference) {
    this.reSubmitTestCaseDetails.testcase.title = correctTitle;
    this.reSubmitTestCaseDetails.testcase.description = correctDescription;
    this.reSubmitTestCaseDetails.testcase.reference = correctReference;

    let testdata = {
      title: this.reSubmitTestCaseDetails.testcase.title,
      description: this.reSubmitTestCaseDetails.testcase.description,
      reference: correctReference.trim()
    };

    this.dataService.uploadtestCase(this.url, testdata, this.tagValue).subscribe((result) => {
      this.testcaseInsertionReport.push(result);
    });
    this.resubmitFlag = false;
    this.testcaseInsertionReport.splice(this.reSubmitIndex, 1);
  }

  onUploadTestCaseFinish() {
    this.tagValue = 'Enter_Tag';
    this.tagSetFlag = false;
    this.title = '';
    this.description = '';
    this.reference = '';
    this.masterPassword = '';
    this.submitflag = true;
    this.finishFlag = true;
    this.submitButton = true;
    this.inputTagDisabled = false;
    this.uploadToTaffyButton = 'Upload To Taffy';
    this.resubmitFlag = false;
    this.testcaseInsertionReport = [];
    this.onDelete();
  }

  ngOnDestroy() {
    if (!this.submitButton) {
      this.onDelete();
    }
  }
}
