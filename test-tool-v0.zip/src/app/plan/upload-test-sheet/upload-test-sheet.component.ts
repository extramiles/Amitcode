import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { NgForm } from '@angular/forms';
import { StateDataService } from '../../shared/state-data-service';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../shared/data.service';

@Component({
  selector: 'app-upload-test-sheet',
  templateUrl: './upload-test-sheet.component.html',
  styleUrls: ['./upload-test-sheet.component.css']
})
export class UploadTestSheetComponent implements OnInit {
  dataToUpload = [];
  testcases = [];
  constructor(private stateDataService: StateDataService,
    private route: ActivatedRoute,
    private router: Router
  ) { }
  arrayBuffer: any;
  file: File;
  fileTypeError: { name: string, fileselectMethod: string }[] = [];
  dropBoxClass = '';


  ngOnInit() {
    this.dataToUpload = this.stateDataService.getData();
  }



  incomingfile(event, fileselectMethod) {
    this.handleDrop(event.target.files, fileselectMethod);
  }
  

  handleDrop(fileList, fileselectMethod) {
    for (let file of fileList) {
      this.file = file;
      if (file.name.split('.').pop() === 'xlsx') {
        for (var i = 0; i < this.dataToUpload.length; i++) {
          if (file.name === this.dataToUpload[i].fileName) {
            this.dataToUpload.splice(i, 1);
          }
        }
        this.UploadDrop(file.name, fileselectMethod);
      }
      else {
        this.fileTypeError.push({ name: file.name, fileselectMethod: 'File Not Proccessed' });
      }
    }
    this.stateDataService.setData(this.dataToUpload);
  }

  UploadDrop(fileName, fileselectMethod) {
    let fileReader = new FileReader();
    fileReader.onload = (e) => {
      this.arrayBuffer = fileReader.result;
      var data = new Uint8Array(this.arrayBuffer);
      var arr = new Array();
      for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
      var bstr = arr.join("");
      var workbook = XLSX.read(bstr, { type: "binary" });
      var first_sheet_name = workbook.SheetNames[0];
      var worksheet = workbook.Sheets[first_sheet_name];
      this.testcases = XLSX.utils.sheet_to_json(worksheet, { raw: true });
      if (this.testcases[0].Title && this.testcases[0].Description && this.testcases[0].Reference) {
        this.dataToUpload.push({ fileName: fileName, fileselectMethod: fileselectMethod, testcases: this.testcases });
      } else {
        this.fileTypeError.push({ name: fileName, fileselectMethod: 'File Not Proccessed' });
      }
    }
    fileReader.readAsArrayBuffer(this.file);
  }


  removeSheet(index) {
    this.dataToUpload.splice(index, 1);
    this.stateDataService.setData(this.dataToUpload);
  }
  resetUploadData(f: NgForm) {
    this.dataToUpload = [];
    this.testcases = [];
    this.fileTypeError = [];
    f.reset();
    this.stateDataService.setData(this.dataToUpload);
  }

  handleCSS(event) {
    if (event) {
      this.dropBoxClass = 'hover';
    } else {
      this.dropBoxClass = '';
    }
  }

  toFinalSubmit() {
    this.router.navigate(['../finalSubmit'], { relativeTo: this.route });
  }
}
