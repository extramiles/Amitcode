import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PlaningComponent } from './plan/planing.component';
import { UploadTestSheetComponent } from './plan/upload-test-sheet/upload-test-sheet.component';
import { TestcasesComponent } from './plan/testcases/testcases.component';
import { TestsheetComponent } from './plan/testsheet/testsheet.component';
import { CreateTestSheetComponent } from './plan/create-test-sheet/create-test-sheet.component';

const appRoutes: Routes = [
  { path: '', redirectTo: '/plan', pathMatch:'full' },
  {
    path: 'plan', component: PlaningComponent, children: [
      { path: 'upload', component: UploadTestSheetComponent },
      { path: 'create', component: CreateTestSheetComponent },
      { path: 'finalSubmit', component: TestsheetComponent },
      { path: 'viewTestCases', component: TestcasesComponent },
    ]
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
