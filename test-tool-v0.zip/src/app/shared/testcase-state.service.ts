import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable({
  providedIn: 'root'
})
export class TestcaseStateService {
  private testcases = [];
  private testcasesWithSteps = [];
  private sheetName = 'BlankSheet';
  suitName = 'Test Suit Name/Description';
  suitDescription = 'Test Suit Name/Description';
  testPhaseSelected = 'Integrated Systems Test (IST)';
  regreProgression = 'Progression';
  applicationSelected = 'OPUS - C:18257';
  nonMOTSTeamSelected = 'RCC ST-OPUS';
  user1Modified = 'User 1';
  user2Modified = 'User 2';
  optionsToDisplay = 'update';

   testCasesChanged = new Subject<any[]>();
   testCasesWithStepsChanged = new Subject<any[]>();
   testSuitNameChanged = new Subject<string>();
   testSuitDescriptionChanged = new Subject<string>();
   testPhaseSelectedChanged = new Subject<string>();
   regreProgressionChanged = new Subject<string>();
   applicationSelectedChanged = new Subject<string>();
   nonMOTSTeamSelectedChanged = new Subject<string>();
   user1ModifiedChanged = new Subject<string>();
   user2ModifiedChanged = new Subject<string>();
 

  constructor() { }

  setTestCases(testcases: any[], sheetName) {
    this.testcases = testcases;
    this.sheetName = sheetName;
    this.testCasesChanged.next(this.testcases);
  }

  setTestCasesWithSteps(testcases: any[]) {
    this.testcasesWithSteps = testcases;
    this.testCasesWithStepsChanged.next(this.testcasesWithSteps);
  }

  setSuitName(suitName: string) {
    this.suitName = suitName;
    this.testSuitNameChanged.next(this.suitName);
  }

  setSuitDescription(suitDescription: string) {
    this.suitDescription = suitDescription;
    this.testSuitDescriptionChanged.next(this.suitDescription);
  }

  setTestPhaseSelected(testPhaseSelected: string) {
    if (this.testPhaseSelected !== testPhaseSelected) {
      this.testPhaseSelected = testPhaseSelected;
      this.testPhaseSelectedChanged.next(this.testPhaseSelected);
    }   
  }

  setRegreProgression(regreProgression: string) {
    if (this.regreProgression !== regreProgression) {
      this.regreProgression = regreProgression;
      this.regreProgressionChanged.next(this.regreProgression);
    }
  }
  setapplicationSelected(applicationSelected: string) {
    if (this.applicationSelected !== applicationSelected) {
      this.applicationSelected = applicationSelected;
      this.applicationSelectedChanged.next(this.applicationSelected);
    }
  }
  setnonMOTSTeamSelected(nonMOTSTeamSelected: string) {
    if (this.nonMOTSTeamSelected !== nonMOTSTeamSelected) {
      this.nonMOTSTeamSelected = nonMOTSTeamSelected;
      this.nonMOTSTeamSelectedChanged.next(this.nonMOTSTeamSelected);
    }
  }
  setuser1Modified(user1Modified: string) {
    if (this.user1Modified !== user1Modified) {
      this.user1Modified = user1Modified;
      this.user1ModifiedChanged.next(this.user1Modified);
    }
  }

  setuser2Modified(user2Modified: string) {
    if (this.user2Modified !== user2Modified) {
      this.user2Modified = user2Modified;
      this.user2ModifiedChanged.next(this.user2Modified);
    }
  }

  setOptionsToDisplay(optionsToDisplay: string) {
    this.optionsToDisplay = optionsToDisplay;
  }

  getOptionsToDisplay() {
    return this.optionsToDisplay;
  }

  getTestCases() {
    return this.testcases;
  }

  getTestCasesWithSteps() {
    return this.testcasesWithSteps;
  }

  getSheetName() {
    return this.sheetName;
  }

  getTestCaseList() {
    let testcasesList = [];
    for (let test of this.testcases) {
      for (let t of test) {
        testcasesList.push({ Title: t.name, Description: t.description });
      }
    }
    return testcasesList;
  }

  getSuitName() {
    return this.suitName;
  }
  getSuitDescription() {
    return this.suitDescription;
  }
  getTestPhaseSelected() {
    return this.testPhaseSelected;
  }
  getRegreProgression() {
    return this.regreProgression;
  }
  getApplicationSelected() {
    return this.applicationSelected;
  }
  getNonMOTSTeamSelected() {
    return this.nonMOTSTeamSelected;
  }
  getUser1Modified() {
    return this.user1Modified;
  }
  getUser2Modified() {
    return this.user2Modified;
  }

  resetValues() {
    this.testPhaseSelected = 'Integrated Systems Test (IST)';
    this.regreProgression = 'Progression';
    this.applicationSelected = 'OPUS - C:18257';
    this.nonMOTSTeamSelected = 'RCC ST-OPUS';
    this.user1Modified = 'User 1';
    this.user2Modified = 'User 2';
  
    this.testPhaseSelectedChanged.next(this.testPhaseSelected);
    this.regreProgressionChanged.next(this.regreProgression);
    this.applicationSelectedChanged.next(this.applicationSelected);
    this.nonMOTSTeamSelectedChanged.next(this.nonMOTSTeamSelected);
    this.user1ModifiedChanged.next(this.user1Modified);
    this.user2ModifiedChanged.next(this.user2Modified);
  }
}
