import { Injectable, ElementRef } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';

const EXCEL_EXTENSION = '.xlsx';

@Injectable({
  providedIn: 'root'
})
export class ExportToExcelService {

  private tableWithoutSteps: ElementRef;
  private tableWithSteps: ElementRef;

  constructor() { }
  public exportAsExcelFile(json: any[], excelFileName: string): void {

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);

    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };

    var excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });

    this.saveAsExcelFile(excelBuffer, excelFileName.substring(0, 150));
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });

    FileSaver.saveAs(data, fileName +  EXCEL_EXTENSION);
  }


  setTableWithoutStepsToExport(table: ElementRef) {
    this.tableWithoutSteps = table;
  }

  setTableWithStepsToExport(table: ElementRef) {
    this.tableWithSteps = table;
  }

  public exportTableWithoutSteps(suitName: string) {
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.tableWithoutSteps.nativeElement);
    console.log(ws);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, suitName.substring(0, 30));

    /* save to file */
    XLSX.writeFile(wb, suitName.substring(0, 150) + '.xlsx');
  }


  public exportTableWithSteps(suitName: string) {
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.tableWithSteps.nativeElement);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, suitName.substring(0, 30));

    /* save to file */
    XLSX.writeFile(wb, suitName.substring(0, 150) + '.xlsx');
  }

}
