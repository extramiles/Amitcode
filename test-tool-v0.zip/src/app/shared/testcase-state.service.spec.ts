import { TestBed, inject } from '@angular/core/testing';

import { TestcaseStateService } from './testcase-state.service';

describe('TestcaseStateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TestcaseStateService]
    });
  });

  it('should be created', inject([TestcaseStateService], (service: TestcaseStateService) => {
    expect(service).toBeTruthy();
  }));
});
